import React, { useState, useEffect, useCallback } from 'react';
import { GameCanvas } from '../components/GameCanvas';
import { GameUI } from '../components/UI/GameUI';
import { MobileControls } from '../components/UI/MobileControls';
import { useGameLoop } from '../hooks/useGameLoop';
import { levels } from '../data/levels';

export default function Index() {
  const [currentLevelIndex, setCurrentLevelIndex] = useState(0);
  const [gameComplete, setGameComplete] = useState(false);
  const [totalScore, setTotalScore] = useState(0);
  const currentLevel = levels[currentLevelIndex];
  
  const { gameState, resetPlayer, setMobileControl, shootBullet } = useGameLoop(currentLevel);

  const handleNextLevel = useCallback(() => {
    if (currentLevelIndex < levels.length - 1) {
      setCurrentLevelIndex(prev => prev + 1);
      setTotalScore(gameState.score);
    } else {
      setGameComplete(true);
      setTotalScore(gameState.score);
    }
  }, [currentLevelIndex, gameState.score]);

  const handlePrevLevel = useCallback(() => {
    if (currentLevelIndex > 0) {
      setCurrentLevelIndex(prev => prev - 1);
      setGameComplete(false);
    }
  }, [currentLevelIndex]);

  const handleRestart = useCallback(() => {
    resetPlayer();
  }, [resetPlayer]);

  // Mobile control handlers
  const handleMoveLeft = useCallback(() => {
    setMobileControl('left', true);
  }, [setMobileControl]);

  const handleMoveRight = useCallback(() => {
    setMobileControl('right', true);
  }, [setMobileControl]);

  const handleJump = useCallback(() => {
    setMobileControl('jump', true);
    setTimeout(() => setMobileControl('jump', false), 100);
  }, [setMobileControl]);

  const handleShoot = useCallback(() => {
    setMobileControl('shoot', true);
    setTimeout(() => setMobileControl('shoot', false), 100);
  }, [setMobileControl]);

  const handleStopMove = useCallback(() => {
    setMobileControl('left', false);
    setMobileControl('right', false);
  }, [setMobileControl]);

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === 'r' || e.key === 'R') {
        handleRestart();
      } else if (e.key === ' ' && gameState.levelComplete) {
        e.preventDefault();
        handleNextLevel();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [handleRestart, handleNextLevel, gameState.levelComplete]);

  // Auto-advance on level complete after delay
  useEffect(() => {
    if (gameState.levelComplete && !gameComplete) {
      const timer = setTimeout(() => {
        handleNextLevel();
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [gameState.levelComplete, gameComplete, handleNextLevel]);

  return (
    <div className="min-h-screen bg-black text-white p-4 pb-20 md:pb-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-6">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-red-500 to-orange-500 bg-clip-text text-transparent">
            LIMBO COMBAT PLATFORMER
          </h1>
          <p className="text-gray-400">Fight enemies and navigate dark, atmospheric puzzle levels</p>
        </div>

        {gameComplete ? (
          <div className="text-center space-y-6">
            <div className="bg-gradient-to-r from-green-900 to-blue-900 p-8 rounded-lg border border-green-700">
              <h2 className="text-3xl font-bold text-green-400 mb-4">🎉 Congratulations! 🎉</h2>
              <p className="text-xl text-white mb-4">You've completed all 10 levels!</p>
              <div className="text-2xl font-bold text-yellow-400 mb-2">
                Final Score: {totalScore.toLocaleString()}
              </div>
              <div className="text-lg text-gray-300 mb-4">
                Total Deaths: {gameState.deaths}
              </div>
              <p className="text-gray-300">You've mastered the dark world of combat platforming!</p>
              <button
                onClick={() => {
                  setCurrentLevelIndex(0);
                  setGameComplete(false);
                  setTotalScore(0);
                }}
                className="mt-4 px-6 py-2 bg-green-600 hover:bg-green-700 rounded-lg font-semibold"
              >
                Play Again
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Game Canvas */}
            <div className="lg:col-span-3 flex justify-center">
              <GameCanvas levelData={currentLevel} gameState={gameState} />
            </div>

            {/* Game UI */}
            <div className="lg:col-span-1">
              <GameUI
                currentLevel={currentLevel.id}
                totalLevels={levels.length}
                levelName={currentLevel.name}
                levelDescription={currentLevel.description}
                onRestart={handleRestart}
                onNextLevel={handleNextLevel}
                onPrevLevel={handlePrevLevel}
                gameComplete={gameComplete}
                playerAlive={gameState.player.alive}
                levelComplete={gameState.levelComplete}
                score={gameState.score}
                deaths={gameState.deaths}
                playerHealth={gameState.player.health}
                playerAmmo={gameState.player.ammo}
                hasWeapon={gameState.player.hasWeapon}
                enemiesRemaining={gameState.enemies.length}
              />
            </div>
          </div>
        )}

        {/* Level Progress */}
        <div className="mt-6">
          <div className="bg-gray-900 rounded-lg p-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-400">Progress</span>
              <span className="text-sm text-gray-400">
                {currentLevelIndex + 1} / {levels.length}
              </span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-red-500 to-orange-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${((currentLevelIndex + 1) / levels.length) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* Mobile Controls */}
        <MobileControls
          onMoveLeft={handleMoveLeft}
          onMoveRight={handleMoveRight}
          onJump={handleJump}
          onShoot={handleShoot}
          onStopMove={handleStopMove}
        />
      </div>
    </div>
  );
}