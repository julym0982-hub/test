import { useState, useEffect, useCallback, useRef } from 'react';
import { LevelData, GameObject } from '../data/levels';

export interface Player {
  x: number;
  y: number;
  width: number;
  height: number;
  velocityX: number;
  velocityY: number;
  onGround: boolean;
  alive: boolean;
  hasWeapon: boolean;
  ammo: number;
  health: number;
}

export interface Enemy {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  velocityX: number;
  velocityY: number;
  health: number;
  type: 'walker' | 'jumper' | 'shooter';
  lastShot: number;
  direction: number;
  patrolStart?: number;
  patrolEnd?: number;
}

export interface Bullet {
  id: string;
  x: number;
  y: number;
  velocityX: number;
  velocityY: number;
  fromPlayer: boolean;
}

export interface GameState {
  currentLevel: number;
  player: Player;
  enemies: Enemy[];
  bullets: Bullet[];
  gameObjects: GameObject[];
  keys: { [key: string]: boolean };
  mobileControls: { [key: string]: boolean };
  gameTime: number;
  levelComplete: boolean;
  score: number;
  deaths: number;
  levelStartTime: number;
}

export const useGameLoop = (levelData: LevelData | null) => {
  const [gameState, setGameState] = useState<GameState>({
    currentLevel: 1,
    player: {
      x: 100,
      y: 400,
      width: 20,
      height: 30,
      velocityX: 0,
      velocityY: 0,
      onGround: false,
      alive: true,
      hasWeapon: false,
      ammo: 0,
      health: 3
    },
    enemies: [],
    bullets: [],
    gameObjects: [],
    keys: {},
    mobileControls: {},
    gameTime: 0,
    levelComplete: false,
    score: 0,
    deaths: 0,
    levelStartTime: 0
  });

  const gameLoopRef = useRef<number>();
  const lastTimeRef = useRef<number>(0);
  const bulletIdCounter = useRef<number>(0);

  const resetPlayer = useCallback(() => {
    if (!levelData) return;
    
    // Initialize enemies from level data
    const enemies: Enemy[] = levelData.objects
      .filter(obj => obj.type === 'enemy')
      .map(obj => ({
        id: obj.id,
        x: obj.x,
        y: obj.y,
        width: obj.width,
        height: obj.height,
        velocityX: 0,
        velocityY: 0,
        health: obj.properties?.health || 1,
        type: obj.properties?.enemyType || 'walker',
        lastShot: 0,
        direction: 1,
        patrolStart: obj.properties?.patrolStart,
        patrolEnd: obj.properties?.patrolEnd
      }));
    
    setGameState(prev => ({
      ...prev,
      player: {
        ...prev.player,
        x: levelData.playerStart.x,
        y: levelData.playerStart.y,
        velocityX: 0,
        velocityY: 0,
        onGround: false,
        alive: true,
        health: 3
      },
      enemies,
      bullets: [],
      levelComplete: false,
      deaths: prev.deaths + (prev.player.alive ? 0 : 1),
      levelStartTime: Date.now()
    }));
  }, [levelData]);

  const checkCollision = (rect1: Player | GameObject | Enemy | Bullet, rect2: GameObject | Enemy | Player) => {
    return rect1.x < rect2.x + rect2.width &&
           rect1.x + rect1.width > rect2.x &&
           rect1.y < rect2.y + rect2.height &&
           rect1.y + rect1.height > rect2.y;
  };

  const shootBullet = useCallback((fromPlayer: boolean, x: number, y: number, direction: number) => {
    setGameState(prev => {
      if (fromPlayer && (!prev.player.hasWeapon || prev.player.ammo <= 0)) return prev;
      
      const newBullet: Bullet = {
        id: `bullet_${bulletIdCounter.current++}`,
        x: x,
        y: y + 10,
        velocityX: direction * 8,
        velocityY: 0,
        fromPlayer
      };

      return {
        ...prev,
        bullets: [...prev.bullets, newBullet],
        player: fromPlayer ? { ...prev.player, ammo: prev.player.ammo - 1 } : prev.player
      };
    });
  }, []);

  const updatePlayer = useCallback((deltaTime: number) => {
    setGameState(prev => {
      if (!prev.player.alive || !levelData) return prev;

      const newPlayer = { ...prev.player };
      const gravity = 0.6;
      const moveSpeed = 3;
      const jumpPower = -18;

      // Handle input (keyboard + mobile)
      const moveLeft = prev.keys['ArrowLeft'] || prev.keys['a'] || prev.mobileControls['left'];
      const moveRight = prev.keys['ArrowRight'] || prev.keys['d'] || prev.mobileControls['right'];
      const jump = prev.keys[' '] || prev.keys['ArrowUp'] || prev.keys['w'] || prev.mobileControls['jump'];
      const shoot = prev.keys['x'] || prev.keys['X'] || prev.mobileControls['shoot'];

      if (moveLeft) {
        newPlayer.velocityX = -moveSpeed;
      } else if (moveRight) {
        newPlayer.velocityX = moveSpeed;
      } else {
        newPlayer.velocityX *= 0.85;
      }

      if (jump && newPlayer.onGround) {
        newPlayer.velocityY = jumpPower;
        newPlayer.onGround = false;
      }

      if (shoot && newPlayer.hasWeapon && newPlayer.ammo > 0) {
        const direction = newPlayer.velocityX >= 0 ? 1 : -1;
        shootBullet(true, newPlayer.x, newPlayer.y, direction);
      }

      // Apply gravity
      newPlayer.velocityY += gravity;
      if (newPlayer.velocityY > 12) {
        newPlayer.velocityY = 12;
      }

      // Update position
      newPlayer.x += newPlayer.velocityX;
      newPlayer.y += newPlayer.velocityY;

      // Check platform collisions
      newPlayer.onGround = false;
      levelData.objects.forEach(obj => {
        if (obj.type === 'platform' || obj.type === 'movingPlatform') {
          if (checkCollision(newPlayer, obj)) {
            if (newPlayer.velocityY > 0 && newPlayer.y < obj.y) {
              newPlayer.y = obj.y - newPlayer.height;
              newPlayer.velocityY = 0;
              newPlayer.onGround = true;
            } else if (newPlayer.velocityY < 0 && newPlayer.y > obj.y) {
              newPlayer.y = obj.y + obj.height;
              newPlayer.velocityY = 0;
            } else if (newPlayer.velocityX > 0) {
              newPlayer.x = obj.x - newPlayer.width;
              newPlayer.velocityX = 0;
            } else if (newPlayer.velocityX < 0) {
              newPlayer.x = obj.x + obj.width;
              newPlayer.velocityX = 0;
            }
          }
        }
      });

      // Check powerups
      levelData.objects.forEach(obj => {
        if (obj.type === 'powerup' && checkCollision(newPlayer, obj)) {
          if (obj.properties?.powerupType === 'weapon') {
            newPlayer.hasWeapon = true;
            newPlayer.ammo += 10;
          } else if (obj.properties?.powerupType === 'ammo') {
            newPlayer.ammo += 5;
          } else if (obj.properties?.powerupType === 'health') {
            newPlayer.health = Math.min(3, newPlayer.health + 1);
          }
          // Remove powerup (mark as collected)
          obj.type = 'platform'; // Temporary hack to "remove" it
          obj.width = 0;
          obj.height = 0;
        }
      });

      // Check enemy collisions
      prev.enemies.forEach(enemy => {
        if (checkCollision(newPlayer, enemy)) {
          newPlayer.health -= 1;
          if (newPlayer.health <= 0) {
            newPlayer.alive = false;
          }
        }
      });

      // Check deadly obstacles
      levelData.objects.forEach(obj => {
        if ((obj.type === 'spike' || obj.type === 'saw') && checkCollision(newPlayer, obj)) {
          newPlayer.alive = false;
        }
      });

      // Check goal
      const goal = levelData.objects.find(obj => obj.type === 'goal');
      if (goal && checkCollision(newPlayer, goal)) {
        const timeBonus = Math.max(0, 1000 - Math.floor((Date.now() - prev.levelStartTime) / 100));
        const deathPenalty = prev.deaths * 50;
        const enemyBonus = (levelData.objects.filter(obj => obj.type === 'enemy').length - prev.enemies.length) * 100;
        const levelScore = Math.max(100, timeBonus - deathPenalty + enemyBonus);
        
        return { 
          ...prev, 
          player: newPlayer, 
          levelComplete: true,
          score: prev.score + levelScore
        };
      }

      // Boundary checks
      if (newPlayer.x < 0) newPlayer.x = 0;
      if (newPlayer.x + newPlayer.width > 900) newPlayer.x = 900 - newPlayer.width;
      if (newPlayer.y > 600) newPlayer.alive = false;

      return { ...prev, player: newPlayer };
    });
  }, [levelData, shootBullet]);

  const updateEnemies = useCallback((deltaTime: number) => {
    if (!levelData) return;

    setGameState(prev => {
      const updatedEnemies = prev.enemies.map(enemy => {
        const newEnemy = { ...enemy };
        
        switch (enemy.type) {
          case 'walker': {
            if (enemy.patrolStart !== undefined && enemy.patrolEnd !== undefined) {
              if (newEnemy.x <= enemy.patrolStart) newEnemy.direction = 1;
              if (newEnemy.x >= enemy.patrolEnd) newEnemy.direction = -1;
              newEnemy.velocityX = newEnemy.direction * 1;
            }
            break;
          }
          case 'jumper': {
            const distanceToPlayer = Math.abs(newEnemy.x - prev.player.x);
            if (distanceToPlayer < 150 && Math.random() < 0.01) {
              newEnemy.velocityY = -12;
              newEnemy.velocityX = prev.player.x > newEnemy.x ? 2 : -2;
            }
            break;
          }
          case 'shooter': {
            const distanceToPlayer = Math.abs(newEnemy.x - prev.player.x);
            if (distanceToPlayer < 200 && Date.now() - enemy.lastShot > 2000) {
              const direction = prev.player.x > newEnemy.x ? 1 : -1;
              shootBullet(false, newEnemy.x, newEnemy.y, direction);
              newEnemy.lastShot = Date.now();
            }
            break;
          }
        }

        newEnemy.velocityY += 0.6;
        newEnemy.x += newEnemy.velocityX;
        newEnemy.y += newEnemy.velocityY;

        levelData.objects.forEach(obj => {
          if (obj.type === 'platform') {
            if (checkCollision(newEnemy, obj)) {
              if (newEnemy.velocityY > 0 && newEnemy.y < obj.y) {
                newEnemy.y = obj.y - newEnemy.height;
                newEnemy.velocityY = 0;
              }
            }
          }
        });

        return newEnemy;
      });

      return { ...prev, enemies: updatedEnemies };
    });
  }, [levelData, shootBullet]);

  const updateBullets = useCallback(() => {
    setGameState(prev => {
      const updatedBullets = prev.bullets
        .map(bullet => ({
          ...bullet,
          x: bullet.x + bullet.velocityX,
          y: bullet.y + bullet.velocityY
        }))
        .filter(bullet => bullet.x > -50 && bullet.x < 950 && bullet.y > -50 && bullet.y < 550);

      const remainingBullets: Bullet[] = [];
      const updatedEnemies = [...prev.enemies];
      const updatedPlayer = { ...prev.player };

      updatedBullets.forEach(bullet => {
        let bulletHit = false;

        if (bullet.fromPlayer) {
          for (let i = 0; i < updatedEnemies.length; i++) {
            if (checkCollision(bullet, updatedEnemies[i])) {
              updatedEnemies[i].health -= 1;
              if (updatedEnemies[i].health <= 0) {
                updatedEnemies.splice(i, 1);
              }
              bulletHit = true;
              break;
            }
          }
        } else {
          if (checkCollision(bullet, updatedPlayer)) {
            updatedPlayer.health -= 1;
            if (updatedPlayer.health <= 0) {
              updatedPlayer.alive = false;
            }
            bulletHit = true;
          }
        }

        if (!bulletHit) {
          remainingBullets.push(bullet);
        }
      });

      return { ...prev, bullets: remainingBullets, enemies: updatedEnemies, player: updatedPlayer };
    });
  }, []);

  const gameLoop = useCallback((currentTime: number) => {
    const deltaTime = currentTime - lastTimeRef.current;
    lastTimeRef.current = currentTime;

    updatePlayer(deltaTime);
    updateEnemies(deltaTime);
    updateBullets();

    setGameState(prev => ({
      ...prev,
      gameTime: prev.gameTime + deltaTime
    }));

    gameLoopRef.current = requestAnimationFrame(gameLoop);
  }, [updatePlayer, updateEnemies, updateBullets]);

  // Mobile control functions
  const setMobileControl = useCallback((control: string, active: boolean) => {
    setGameState(prev => ({
      ...prev,
      mobileControls: { ...prev.mobileControls, [control]: active }
    }));
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      setGameState(prev => ({
        ...prev,
        keys: { ...prev.keys, [e.key]: true }
      }));
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      setGameState(prev => ({
        ...prev,
        keys: { ...prev.keys, [e.key]: false }
      }));
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  useEffect(() => {
    if (levelData) {
      resetPlayer();
      gameLoopRef.current = requestAnimationFrame(gameLoop);
    }

    return () => {
      if (gameLoopRef.current) {
        cancelAnimationFrame(gameLoopRef.current);
      }
    };
  }, [levelData, gameLoop, resetPlayer]);

  return { gameState, resetPlayer, setMobileControl, shootBullet };
};