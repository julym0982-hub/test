export interface GameObject {
  id: string;
  type: 'platform' | 'spike' | 'door' | 'switch' | 'movingPlatform' | 'saw' | 'gravityWell' | 'goal' | 'enemy' | 'powerup';
  x: number;
  y: number;
  width: number;
  height: number;
  properties?: {
    speed?: number;
    direction?: 'horizontal' | 'vertical';
    range?: number;
    isActive?: boolean;
    linkedTo?: string;
    gravityStrength?: number;
    rotationSpeed?: number;
    enemyType?: 'walker' | 'jumper' | 'shooter';
    health?: number;
    powerupType?: 'weapon' | 'health' | 'ammo';
    patrolStart?: number;
    patrolEnd?: number;
  };
}

export interface LevelData {
  id: number;
  name: string;
  playerStart: { x: number; y: number };
  objects: GameObject[];
  backgroundColor: string;
  description: string;
}

export const levels: LevelData[] = [
  {
    id: 1,
    name: "First Steps",
    description: "Learn to move and jump",
    backgroundColor: "#1a1a1a",
    playerStart: { x: 100, y: 400 },
    objects: [
      { id: "ground1", type: "platform", x: 0, y: 450, width: 300, height: 50 },
      { id: "platform1", type: "platform", x: 400, y: 350, width: 150, height: 20 },
      { id: "platform2", type: "platform", x: 650, y: 250, width: 150, height: 20 },
      { id: "goal1", type: "goal", x: 720, y: 200, width: 30, height: 50 }
    ]
  },
  {
    id: 2,
    name: "First Enemy",
    description: "Defeat or avoid the walking enemy",
    backgroundColor: "#1a1a1a",
    playerStart: { x: 50, y: 400 },
    objects: [
      { id: "ground1", type: "platform", x: 0, y: 450, width: 200, height: 50 },
      { id: "enemy1", type: "enemy", x: 250, y: 420, width: 20, height: 30,
        properties: { enemyType: "walker", speed: 1, patrolStart: 200, patrolEnd: 400, health: 1 } },
      { id: "platform1", type: "platform", x: 200, y: 450, width: 250, height: 50 },
      { id: "powerup1", type: "powerup", x: 320, y: 420, width: 15, height: 15,
        properties: { powerupType: "weapon" } },
      { id: "spikes1", type: "spike", x: 500, y: 430, width: 60, height: 20 },
      { id: "platform2", type: "platform", x: 560, y: 450, width: 200, height: 50 },
      { id: "goal1", type: "goal", x: 720, y: 400, width: 30, height: 50 }
    ]
  },
  {
    id: 3,
    name: "Moving Platforms & Enemies",
    description: "Navigate moving platforms while avoiding enemies",
    backgroundColor: "#1a1a1a",
    playerStart: { x: 50, y: 400 },
    objects: [
      { id: "ground1", type: "platform", x: 0, y: 450, width: 150, height: 50 },
      { id: "movingPlatform1", type: "movingPlatform", x: 200, y: 350, width: 100, height: 20, 
        properties: { speed: 2, direction: "vertical", range: 100 } },
      { id: "enemy1", type: "enemy", x: 220, y: 320, width: 20, height: 30,
        properties: { enemyType: "jumper", speed: 2, health: 1 } },
      { id: "platform1", type: "platform", x: 400, y: 300, width: 100, height: 20 },
      { id: "movingPlatform2", type: "movingPlatform", x: 550, y: 200, width: 100, height: 20,
        properties: { speed: 3, direction: "horizontal", range: 150 } },
      { id: "goal1", type: "goal", x: 720, y: 350, width: 30, height: 50 },
      { id: "platform2", type: "platform", x: 700, y: 400, width: 100, height: 50 }
    ]
  },
  {
    id: 4,
    name: "Armed Combat",
    description: "Use weapons to defeat shooting enemies",
    backgroundColor: "#1a1a1a",
    playerStart: { x: 50, y: 400 },
    objects: [
      { id: "ground1", type: "platform", x: 0, y: 450, width: 300, height: 50 },
      { id: "powerup1", type: "powerup", x: 100, y: 420, width: 15, height: 15,
        properties: { powerupType: "weapon" } },
      { id: "enemy1", type: "enemy", x: 350, y: 320, width: 20, height: 30,
        properties: { enemyType: "shooter", speed: 0, health: 2 } },
      { id: "platform1", type: "platform", x: 330, y: 350, width: 60, height: 20 },
      { id: "switch1", type: "switch", x: 250, y: 430, width: 30, height: 20, 
        properties: { linkedTo: "door1", isActive: false } },
      { id: "door1", type: "door", x: 500, y: 250, width: 20, height: 100,
        properties: { isActive: false, linkedTo: "switch1" } },
      { id: "platform2", type: "platform", x: 550, y: 350, width: 200, height: 20 },
      { id: "goal1", type: "goal", x: 720, y: 300, width: 30, height: 50 }
    ]
  },
  {
    id: 5,
    name: "Gravity & Enemies",
    description: "Use gravity wells while fighting enemies",
    backgroundColor: "#1a1a1a",
    playerStart: { x: 50, y: 400 },
    objects: [
      { id: "ground1", type: "platform", x: 0, y: 450, width: 200, height: 50 },
      { id: "enemy1", type: "enemy", x: 280, y: 320, width: 20, height: 30,
        properties: { enemyType: "walker", speed: 1.5, patrolStart: 250, patrolEnd: 380, health: 1 } },
      { id: "platform1", type: "platform", x: 300, y: 350, width: 100, height: 20 },
      { id: "gravityWell1", type: "gravityWell", x: 350, y: 200, width: 50, height: 50,
        properties: { gravityStrength: -0.5 } },
      { id: "platform2", type: "platform", x: 500, y: 150, width: 100, height: 20 },
      { id: "enemy2", type: "enemy", x: 520, y: 120, width: 20, height: 30,
        properties: { enemyType: "shooter", speed: 0, health: 1 } },
      { id: "platform3", type: "platform", x: 650, y: 250, width: 100, height: 20 },
      { id: "goal1", type: "goal", x: 720, y: 200, width: 30, height: 50 }
    ]
  },
  {
    id: 6,
    name: "Spinning Saws & Guards",
    description: "Navigate through blades and enemy guards",
    backgroundColor: "#1a1a1a",
    playerStart: { x: 50, y: 400 },
    objects: [
      { id: "ground1", type: "platform", x: 0, y: 450, width: 150, height: 50 },
      { id: "platform1", type: "platform", x: 200, y: 350, width: 100, height: 20 },
      { id: "saw1", type: "saw", x: 300, y: 300, width: 40, height: 40,
        properties: { rotationSpeed: 5 } },
      { id: "enemy1", type: "enemy", x: 380, y: 220, width: 20, height: 30,
        properties: { enemyType: "jumper", speed: 2, health: 2 } },
      { id: "platform2", type: "platform", x: 400, y: 250, width: 100, height: 20 },
      { id: "saw2", type: "saw", x: 550, y: 200, width: 40, height: 40,
        properties: { rotationSpeed: -3 } },
      { id: "platform3", type: "platform", x: 650, y: 350, width: 100, height: 20 },
      { id: "powerup1", type: "powerup", x: 680, y: 320, width: 15, height: 15,
        properties: { powerupType: "ammo" } },
      { id: "goal1", type: "goal", x: 720, y: 300, width: 30, height: 50 }
    ]
  },
  {
    id: 7,
    name: "Collapsing Under Fire",
    description: "Move quickly while under enemy fire",
    backgroundColor: "#1a1a1a",
    playerStart: { x: 50, y: 400 },
    objects: [
      { id: "ground1", type: "platform", x: 0, y: 450, width: 150, height: 50 },
      { id: "enemy1", type: "enemy", x: 120, y: 320, width: 20, height: 30,
        properties: { enemyType: "shooter", speed: 0, health: 2 } },
      { id: "platform1", type: "platform", x: 100, y: 350, width: 60, height: 20 },
      { id: "movingPlatform1", type: "movingPlatform", x: 200, y: 350, width: 80, height: 15,
        properties: { speed: 0, direction: "vertical", range: 200, isActive: false } },
      { id: "movingPlatform2", type: "movingPlatform", x: 350, y: 300, width: 80, height: 15,
        properties: { speed: 0, direction: "vertical", range: 200, isActive: false } },
      { id: "enemy2", type: "enemy", x: 480, y: 220, width: 20, height: 30,
        properties: { enemyType: "shooter", speed: 0, health: 1 } },
      { id: "movingPlatform3", type: "movingPlatform", x: 500, y: 250, width: 80, height: 15,
        properties: { speed: 0, direction: "vertical", range: 200, isActive: false } },
      { id: "platform2", type: "platform", x: 650, y: 350, width: 100, height: 20 },
      { id: "goal1", type: "goal", x: 720, y: 300, width: 30, height: 50 }
    ]
  },
  {
    id: 8,
    name: "Enemy Stronghold",
    description: "Defeat multiple enemies to unlock the exit",
    backgroundColor: "#1a1a1a",
    playerStart: { x: 50, y: 400 },
    objects: [
      { id: "ground1", type: "platform", x: 0, y: 450, width: 800, height: 50 },
      { id: "powerup1", type: "powerup", x: 80, y: 420, width: 15, height: 15,
        properties: { powerupType: "weapon" } },
      { id: "enemy1", type: "enemy", x: 200, y: 420, width: 20, height: 30,
        properties: { enemyType: "walker", speed: 1, patrolStart: 150, patrolEnd: 300, health: 2 } },
      { id: "enemy2", type: "enemy", x: 400, y: 420, width: 20, height: 30,
        properties: { enemyType: "shooter", speed: 0, health: 3 } },
      { id: "enemy3", type: "enemy", x: 550, y: 420, width: 20, height: 30,
        properties: { enemyType: "jumper", speed: 2, health: 2 } },
      { id: "switch1", type: "switch", x: 150, y: 430, width: 30, height: 20,
        properties: { linkedTo: "door1", isActive: false } },
      { id: "switch2", type: "switch", x: 350, y: 430, width: 30, height: 20,
        properties: { linkedTo: "door1", isActive: false } },
      { id: "switch3", type: "switch", x: 550, y: 430, width: 30, height: 20,
        properties: { linkedTo: "door1", isActive: false } },
      { id: "door1", type: "door", x: 650, y: 300, width: 20, height: 150,
        properties: { isActive: false, linkedTo: "switch1,switch2,switch3" } },
      { id: "goal1", type: "goal", x: 720, y: 400, width: 30, height: 50 }
    ]
  },
  {
    id: 9,
    name: "Perfect Combat Timing",
    description: "Master combat rhythm with moving obstacles",
    backgroundColor: "#1a1a1a",
    playerStart: { x: 50, y: 400 },
    objects: [
      { id: "ground1", type: "platform", x: 0, y: 450, width: 150, height: 50 },
      { id: "powerup1", type: "powerup", x: 80, y: 420, width: 15, height: 15,
        properties: { powerupType: "weapon" } },
      { id: "movingPlatform1", type: "movingPlatform", x: 200, y: 350, width: 60, height: 15,
        properties: { speed: 4, direction: "vertical", range: 150 } },
      { id: "enemy1", type: "enemy", x: 220, y: 320, width: 20, height: 30,
        properties: { enemyType: "shooter", speed: 0, health: 2 } },
      { id: "saw1", type: "saw", x: 300, y: 300, width: 35, height: 35,
        properties: { rotationSpeed: 8 } },
      { id: "movingPlatform2", type: "movingPlatform", x: 400, y: 200, width: 60, height: 15,
        properties: { speed: 3, direction: "horizontal", range: 100 } },
      { id: "enemy2", type: "enemy", x: 420, y: 170, width: 20, height: 30,
        properties: { enemyType: "jumper", speed: 3, health: 1 } },
      { id: "spikes1", type: "spike", x: 500, y: 430, width: 100, height: 20 },
      { id: "movingPlatform3", type: "movingPlatform", x: 650, y: 300, width: 60, height: 15,
        properties: { speed: 2, direction: "vertical", range: 100 } },
      { id: "goal1", type: "goal", x: 720, y: 250, width: 30, height: 50 }
    ]
  },
  {
    id: 10,
    name: "The Final Battle",
    description: "Use all skills to defeat the final boss area",
    backgroundColor: "#0d0d0d",
    playerStart: { x: 50, y: 400 },
    objects: [
      { id: "ground1", type: "platform", x: 0, y: 450, width: 150, height: 50 },
      { id: "powerup1", type: "powerup", x: 80, y: 420, width: 15, height: 15,
        properties: { powerupType: "weapon" } },
      { id: "switch1", type: "switch", x: 100, y: 430, width: 30, height: 20,
        properties: { linkedTo: "door1", isActive: false } },
      { id: "enemy1", type: "enemy", x: 180, y: 320, width: 20, height: 30,
        properties: { enemyType: "walker", speed: 2, patrolStart: 150, patrolEnd: 250, health: 3 } },
      { id: "movingPlatform1", type: "movingPlatform", x: 200, y: 350, width: 80, height: 15,
        properties: { speed: 2, direction: "vertical", range: 100 } },
      { id: "saw1", type: "saw", x: 320, y: 280, width: 40, height: 40,
        properties: { rotationSpeed: 6 } },
      { id: "enemy2", type: "enemy", x: 380, y: 220, width: 20, height: 30,
        properties: { enemyType: "shooter", speed: 0, health: 4 } },
      { id: "door1", type: "door", x: 400, y: 200, width: 20, height: 120,
        properties: { isActive: false, linkedTo: "switch1" } },
      { id: "gravityWell1", type: "gravityWell", x: 450, y: 150, width: 50, height: 50,
        properties: { gravityStrength: -0.3 } },
      { id: "platform1", type: "platform", x: 550, y: 100, width: 80, height: 15 },
      { id: "enemy3", type: "enemy", x: 570, y: 70, width: 20, height: 30,
        properties: { enemyType: "jumper", speed: 3, health: 2 } },
      { id: "spikes1", type: "spike", x: 630, y: 380, width: 60, height: 20 },
      { id: "switch2", type: "switch", x: 580, y: 80, width: 30, height: 20,
        properties: { linkedTo: "door2", isActive: false } },
      { id: "door2", type: "door", x: 700, y: 250, width: 20, height: 100,
        properties: { isActive: false, linkedTo: "switch2" } },
      { id: "enemy4", type: "enemy", x: 750, y: 170, width: 20, height: 30,
        properties: { enemyType: "shooter", speed: 0, health: 5 } },
      { id: "movingPlatform2", type: "movingPlatform", x: 750, y: 200, width: 60, height: 15,
        properties: { speed: 3, direction: "horizontal", range: 80 } },
      { id: "goal1", type: "goal", x: 850, y: 350, width: 30, height: 50 },
      { id: "platform2", type: "platform", x: 830, y: 400, width: 70, height: 20 }
    ]
  }
];