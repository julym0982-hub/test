import React, { useRef, useEffect } from 'react';
import { LevelData, GameObject } from '../data/levels';
import { GameState, Player, Enemy, Bullet } from '../hooks/useGameLoop';

interface GameCanvasProps {
  levelData: LevelData;
  gameState: GameState;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({ levelData, gameState }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const drawPlayer = (ctx: CanvasRenderingContext2D, player: Player) => {
    ctx.fillStyle = player.alive ? '#ffffff' : '#ff4444';
    ctx.fillRect(player.x, player.y, player.width, player.height);
    
    // Simple face
    if (player.alive) {
      ctx.fillStyle = '#000000';
      ctx.fillRect(player.x + 5, player.y + 8, 2, 2); // Left eye
      ctx.fillRect(player.x + 13, player.y + 8, 2, 2); // Right eye
      
      // Weapon indicator
      if (player.hasWeapon) {
        ctx.fillStyle = '#ffff00';
        ctx.fillRect(player.x + player.width, player.y + 10, 8, 3);
      }
    }
    
    // Health bar
    const healthBarWidth = 20;
    const healthBarHeight = 3;
    ctx.fillStyle = '#ff0000';
    ctx.fillRect(player.x, player.y - 8, healthBarWidth, healthBarHeight);
    ctx.fillStyle = '#00ff00';
    ctx.fillRect(player.x, player.y - 8, (player.health / 3) * healthBarWidth, healthBarHeight);
  };

  const drawEnemy = (ctx: CanvasRenderingContext2D, enemy: Enemy) => {
    // Enemy body
    ctx.fillStyle = '#ff6666';
    ctx.fillRect(enemy.x, enemy.y, enemy.width, enemy.height);
    
    // Enemy type indicator
    ctx.fillStyle = '#ffffff';
    switch (enemy.type) {
      case 'walker':
        ctx.fillRect(enemy.x + 5, enemy.y + 8, 2, 2);
        ctx.fillRect(enemy.x + 13, enemy.y + 8, 2, 2);
        break;
      case 'jumper':
        ctx.fillRect(enemy.x + 8, enemy.y + 5, 4, 4);
        break;
      case 'shooter':
        ctx.fillRect(enemy.x + 5, enemy.y + 8, 2, 2);
        ctx.fillRect(enemy.x + 13, enemy.y + 8, 2, 2);
        // Gun
        ctx.fillStyle = '#ffff00';
        ctx.fillRect(enemy.x + enemy.width, enemy.y + 10, 6, 2);
        break;
    }
    
    // Health bar
    const healthBarWidth = 20;
    const healthBarHeight = 2;
    const maxHealth = levelData.objects.find(obj => obj.id === enemy.id)?.properties?.health || 1;
    ctx.fillStyle = '#ff0000';
    ctx.fillRect(enemy.x, enemy.y - 6, healthBarWidth, healthBarHeight);
    ctx.fillStyle = '#00ff00';
    ctx.fillRect(enemy.x, enemy.y - 6, (enemy.health / maxHealth) * healthBarWidth, healthBarHeight);
  };

  const drawBullet = (ctx: CanvasRenderingContext2D, bullet: Bullet) => {
    ctx.fillStyle = bullet.fromPlayer ? '#ffff00' : '#ff6666';
    ctx.fillRect(bullet.x, bullet.y, 4, 2);
  };

  const drawObject = (ctx: CanvasRenderingContext2D, obj: GameObject) => {
    switch (obj.type) {
      case 'platform':
      case 'movingPlatform': {
        ctx.fillStyle = '#444444';
        ctx.fillRect(obj.x, obj.y, obj.width, obj.height);
        break;
      }
      
      case 'spike': {
        ctx.fillStyle = '#ff6666';
        ctx.fillRect(obj.x, obj.y, obj.width, obj.height);
        // Draw spikes
        for (let i = 0; i < obj.width; i += 10) {
          ctx.beginPath();
          ctx.moveTo(obj.x + i, obj.y + obj.height);
          ctx.lineTo(obj.x + i + 5, obj.y);
          ctx.lineTo(obj.x + i + 10, obj.y + obj.height);
          ctx.closePath();
          ctx.fill();
        }
        break;
      }
      
      case 'door': {
        ctx.fillStyle = obj.properties?.isActive ? '#66ff66' : '#ff6666';
        ctx.fillRect(obj.x, obj.y, obj.width, obj.height);
        break;
      }
      
      case 'switch': {
        ctx.fillStyle = obj.properties?.isActive ? '#66ff66' : '#ffff66';
        ctx.fillRect(obj.x, obj.y, obj.width, obj.height);
        break;
      }
      
      case 'saw': {
        ctx.fillStyle = '#ff4444';
        ctx.beginPath();
        ctx.arc(obj.x + obj.width/2, obj.y + obj.height/2, obj.width/2, 0, Math.PI * 2);
        ctx.fill();
        
        // Draw teeth
        const teeth = 8;
        const rotation = (gameState.gameTime * (obj.properties?.rotationSpeed || 1)) / 100;
        for (let i = 0; i < teeth; i++) {
          const angle = (i / teeth) * Math.PI * 2 + rotation;
          const x1 = obj.x + obj.width/2 + Math.cos(angle) * (obj.width/2 - 2);
          const y1 = obj.y + obj.height/2 + Math.sin(angle) * (obj.height/2 - 2);
          const x2 = obj.x + obj.width/2 + Math.cos(angle) * (obj.width/2 + 4);
          const y2 = obj.y + obj.height/2 + Math.sin(angle) * (obj.height/2 + 4);
          
          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.strokeStyle = '#ff4444';
          ctx.lineWidth = 2;
          ctx.stroke();
        }
        break;
      }
      
      case 'gravityWell': {
        ctx.fillStyle = 'rgba(100, 100, 255, 0.3)';
        ctx.fillRect(obj.x, obj.y, obj.width, obj.height);
        
        // Draw gravity effect
        const centerX = obj.x + obj.width/2;
        const centerY = obj.y + obj.height/2;
        for (let i = 0; i < 5; i++) {
          ctx.beginPath();
          ctx.arc(centerX, centerY, 10 + i * 8, 0, Math.PI * 2);
          ctx.strokeStyle = `rgba(100, 100, 255, ${0.5 - i * 0.1})`;
          ctx.lineWidth = 1;
          ctx.stroke();
        }
        break;
      }
      
      case 'powerup': {
        ctx.fillStyle = '#00ffff';
        ctx.fillRect(obj.x, obj.y, obj.width, obj.height);
        
        // Powerup type indicator
        ctx.fillStyle = '#ffffff';
        ctx.font = '10px Arial';
        ctx.textAlign = 'center';
        const text = obj.properties?.powerupType === 'weapon' ? 'W' : 
                    obj.properties?.powerupType === 'ammo' ? 'A' : 'H';
        ctx.fillText(text, obj.x + obj.width/2, obj.y + obj.height/2 + 3);
        break;
      }
      
      case 'goal': {
        ctx.fillStyle = '#66ff66';
        ctx.fillRect(obj.x, obj.y, obj.width, obj.height);
        
        // Draw flag
        ctx.fillStyle = '#44dd44';
        ctx.beginPath();
        ctx.moveTo(obj.x + 5, obj.y);
        ctx.lineTo(obj.x + obj.width - 5, obj.y + 10);
        ctx.lineTo(obj.x + 5, obj.y + 20);
        ctx.closePath();
        ctx.fill();
        break;
      }
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = levelData.backgroundColor;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw atmospheric grid
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.lineWidth = 1;
    for (let x = 0; x < canvas.width; x += 50) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += 50) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // Draw game objects (excluding enemies and powerups that are handled separately)
    levelData.objects
      .filter(obj => obj.type !== 'enemy' && !(obj.type === 'powerup' && obj.width === 0))
      .forEach(obj => drawObject(ctx, obj));

    // Draw powerups that haven't been collected
    levelData.objects
      .filter(obj => obj.type === 'powerup' && obj.width > 0)
      .forEach(obj => drawObject(ctx, obj));

    // Draw enemies
    gameState.enemies.forEach(enemy => drawEnemy(ctx, enemy));

    // Draw bullets
    gameState.bullets.forEach(bullet => drawBullet(ctx, bullet));

    // Draw player
    drawPlayer(ctx, gameState.player);

    // Draw UI elements
    ctx.fillStyle = '#ffffff';
    ctx.font = '16px Arial';
    ctx.textAlign = 'left';
    
    // Ammo counter
    if (gameState.player.hasWeapon) {
      ctx.fillText(`Ammo: ${gameState.player.ammo}`, 10, 30);
    }
    
    // Enemy counter
    ctx.fillText(`Enemies: ${gameState.enemies.length}`, 10, 50);

    // Draw level complete message
    if (gameState.levelComplete) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      ctx.fillStyle = '#66ff66';
      ctx.font = '48px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('Level Complete!', canvas.width / 2, canvas.height / 2);
      
      ctx.fillStyle = '#ffffff';
      ctx.font = '24px Arial';
      ctx.fillText('Press SPACE to continue', canvas.width / 2, canvas.height / 2 + 50);
    }

    // Draw death message
    if (!gameState.player.alive) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      
      ctx.fillStyle = '#ff4444';
      ctx.font = '48px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('You Died', canvas.width / 2, canvas.height / 2);
      
      ctx.fillStyle = '#ffffff';
      ctx.font = '24px Arial';
      ctx.fillText('Press R to restart', canvas.width / 2, canvas.height / 2 + 50);
    }
  }, [levelData, gameState]);

  return (
    <canvas
      ref={canvasRef}
      width={900}
      height={500}
      className="border border-gray-600 bg-black"
      style={{ imageRendering: 'pixelated' }}
    />
  );
};