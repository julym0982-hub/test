import React from 'react';
import { Button } from '@/components/ui/button';

interface MobileControlsProps {
  onMoveLeft: () => void;
  onMoveRight: () => void;
  onJump: () => void;
  onShoot: () => void;
  onStopMove: () => void;
}

export const MobileControls: React.FC<MobileControlsProps> = ({
  onMoveLeft,
  onMoveRight,
  onJump,
  onShoot,
  onStopMove
}) => {
  return (
    <div className="fixed bottom-4 left-0 right-0 flex justify-between px-4 md:hidden z-50">
      {/* Movement Controls */}
      <div className="flex space-x-2">
        <Button
          onTouchStart={onMoveLeft}
          onTouchEnd={onStopMove}
          onMouseDown={onMoveLeft}
          onMouseUp={onStopMove}
          className="w-16 h-16 bg-gray-800 border-2 border-gray-600 text-white text-xl font-bold rounded-full"
          variant="outline"
        >
          ←
        </Button>
        <Button
          onTouchStart={onMoveRight}
          onTouchEnd={onStopMove}
          onMouseDown={onMoveRight}
          onMouseUp={onStopMove}
          className="w-16 h-16 bg-gray-800 border-2 border-gray-600 text-white text-xl font-bold rounded-full"
          variant="outline"
        >
          →
        </Button>
      </div>

      {/* Action Controls */}
      <div className="flex space-x-2">
        <Button
          onTouchStart={onShoot}
          onMouseDown={onShoot}
          className="w-16 h-16 bg-red-700 border-2 border-red-500 text-white text-xl font-bold rounded-full"
          variant="outline"
        >
          🔫
        </Button>
        <Button
          onTouchStart={onJump}
          onMouseDown={onJump}
          className="w-16 h-16 bg-blue-700 border-2 border-blue-500 text-white text-xl font-bold rounded-full"
          variant="outline"
        >
          ↑
        </Button>
      </div>
    </div>
  );
};