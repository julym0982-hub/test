import React from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface GameUIProps {
  currentLevel: number;
  totalLevels: number;
  levelName: string;
  levelDescription: string;
  onRestart: () => void;
  onNextLevel: () => void;
  onPrevLevel: () => void;
  gameComplete: boolean;
  playerAlive: boolean;
  levelComplete: boolean;
  score: number;
  deaths: number;
  playerHealth: number;
  playerAmmo: number;
  hasWeapon: boolean;
  enemiesRemaining: number;
}

export const GameUI: React.FC<GameUIProps> = ({
  currentLevel,
  totalLevels,
  levelName,
  levelDescription,
  onRestart,
  onNextLevel,
  onPrevLevel,
  gameComplete,
  playerAlive,
  levelComplete,
  score,
  deaths,
  playerHealth,
  playerAmmo,
  hasWeapon,
  enemiesRemaining
}) => {
  return (
    <div className="w-full space-y-4">
      {/* Player Stats */}
      <Card className="p-3 bg-gray-900 border-gray-700">
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className="flex items-center space-x-2">
            <span className="text-red-400">❤️</span>
            <span className="text-white">{playerHealth}/3</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-yellow-400">🔫</span>
            <span className="text-white">{hasWeapon ? playerAmmo : 'No Weapon'}</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-red-400">👹</span>
            <span className="text-white">{enemiesRemaining}</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-blue-400">💀</span>
            <span className="text-white">{deaths}</span>
          </div>
        </div>
      </Card>

      {/* Score Display */}
      <Card className="p-3 bg-gray-900 border-gray-700">
        <div className="text-center">
          <div className="text-2xl font-bold text-yellow-400">{score.toLocaleString()}</div>
          <div className="text-xs text-gray-400">SCORE</div>
        </div>
      </Card>

      {/* Level Info */}
      <Card className="p-4 bg-gray-900 border-gray-700">
        <div className="flex justify-between items-center mb-2">
          <h2 className="text-xl font-bold text-white">
            Level {currentLevel}: {levelName}
          </h2>
          <div className="text-sm text-gray-400">
            {currentLevel} / {totalLevels}
          </div>
        </div>
        <p className="text-gray-300 text-sm">{levelDescription}</p>
      </Card>

      {/* Controls */}
      <Card className="p-4 bg-gray-900 border-gray-700">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          <Button
            onClick={onPrevLevel}
            disabled={currentLevel <= 1}
            variant="outline"
            size="sm"
            className="bg-gray-800 border-gray-600 text-white hover:bg-gray-700"
          >
            Previous
          </Button>
          <Button
            onClick={onRestart}
            variant="outline"
            size="sm"
            className="bg-gray-800 border-gray-600 text-white hover:bg-gray-700"
          >
            Restart (R)
          </Button>
          <Button
            onClick={onNextLevel}
            disabled={currentLevel >= totalLevels || !levelComplete}
            variant="outline"
            size="sm"
            className="bg-gray-800 border-gray-600 text-white hover:bg-gray-700"
          >
            Next
          </Button>
          <div className="text-xs text-gray-400 flex items-center justify-center">
            {gameComplete ? "All Complete!" : 
             levelComplete ? "Level Complete!" : 
             !playerAlive ? "Dead" : "Playing"}
          </div>
        </div>
      </Card>

      {/* Instructions */}
      <Card className="p-3 bg-gray-900 border-gray-700">
        <div className="text-xs text-gray-400 space-y-1">
          <div><strong>Desktop Controls:</strong></div>
          <div>• Arrow Keys / WASD: Move and Jump</div>
          <div>• Space: Jump</div>
          <div>• X: Shoot (when armed)</div>
          <div>• R: Restart Level</div>
          <div><strong>Mobile Controls:</strong></div>
          <div>• Touch buttons at bottom of screen</div>
          <div><strong>Powerups:</strong></div>
          <div>• W: Weapon (+10 ammo)</div>
          <div>• A: Ammo (+5 rounds)</div>
          <div>• H: Health (+1 life)</div>
          <div><strong>Enemies:</strong></div>
          <div>• Red: Walker/Jumper/Shooter</div>
          <div><strong>Goal:</strong> Reach the green flag!</div>
        </div>
      </Card>
    </div>
  );
};