# Limbo-Style Puzzle Platform Game - MVP Implementation

## Core Files to Create:
1. **src/pages/Index.tsx** - Main game component and level manager
2. **src/components/GameCanvas.tsx** - Canvas-based game renderer
3. **src/components/Player.tsx** - Player character logic
4. **src/components/Level.tsx** - Level data and rendering
5. **src/components/GamePhysics.tsx** - Physics engine utilities
6. **src/components/UI/GameUI.tsx** - Game interface (level counter, restart, etc.)
7. **src/data/levels.ts** - All 10 level configurations
8. **src/hooks/useGameLoop.ts** - Game loop and state management

## Game Features:
- Dark, atmospheric visuals with silhouette-style graphics
- Physics-based movement and interactions
- 10 unique puzzle levels with increasing difficulty
- Obstacles: spikes, moving platforms, switches, doors, gravity wells
- Simple controls: arrow keys + space for jump
- Death and respawn mechanics
- Level progression system

## Level Progression:
1. Basic movement and jumping
2. Simple spike obstacles
3. Moving platforms
4. Pressure switches and doors
5. Gravity manipulation
6. Rotating saw blades
7. Collapsing platforms
8. Multiple switches puzzle
9. Timing-based challenges
10. Final complex multi-element level

## Technical Implementation:
- HTML5 Canvas for rendering
- Custom physics engine for platformer mechanics
- Component-based architecture
- Keyboard input handling
- Collision detection system
- Dark theme with atmospheric lighting effects